let currentImageIndex = 0;

const images = document.querySelectorAll(".gallery-item img");

// Filter Images
function filterImages(category) {
    const items = document.querySelectorAll(".gallery-item");

    items.forEach(item => {
        if (category === "all" || item.classList.contains(category)) {
            item.style.display = "block";
        } else {
            item.style.display = "none";
        }
    });
}

// Open Lightbox
function openLightbox(image) {
    const visibleImages = Array.from(
        document.querySelectorAll(".gallery-item")
    ).filter(item => item.style.display !== "none");

    currentImageIndex = visibleImages.findIndex(
        item => item.querySelector("img") === image
    );

    document.getElementById("lightbox-img").src = image.src;
    document.getElementById("lightbox").style.display = "flex";
}

// Close Lightbox
function closeLightbox() {
    document.getElementById("lightbox").style.display = "none";
}

// Change Image
function changeImage(direction) {
    const visibleImages = Array.from(
        document.querySelectorAll(".gallery-item")
    ).filter(item => item.style.display !== "none");

    if (visibleImages.length === 0) return;

    currentImageIndex += direction;

    if (currentImageIndex < 0) {
        currentImageIndex = visibleImages.length - 1;
    }

    if (currentImageIndex >= visibleImages.length) {
        currentImageIndex = 0;
    }

    const nextImage = visibleImages[currentImageIndex].querySelector("img");

    document.getElementById("lightbox-img").src = nextImage.src;
}

// Close lightbox when clicking outside image
document.getElementById("lightbox").addEventListener("click", function(event) {
    if (event.target === this) {
        closeLightbox();
    }
});

// Keyboard controls
document.addEventListener("keydown", function(event) {
    const lightbox = document.getElementById("lightbox");

    if (lightbox.style.display === "flex") {
        if (event.key === "ArrowLeft") {
            changeImage(-1);
        }

        if (event.key === "ArrowRight") {
            changeImage(1);
        }

        if (event.key === "Escape") {
            closeLightbox();
        }
    }
});